from sklearn.utils import _safe_indexing
import sklearn.neighbors._base
import matplotlib.pyplot as plt
from xgboost import plot_importance, plot_tree, to_graphviz
import pandas as pd
import shap
from matplotlib import pyplot

import operator
import six
import sys
sys.modules['sklearn.externals.six'] = six

sys.modules['sklearn.neighbors.base'] = sklearn.neighbors._base
sys.modules['sklearn.utils.safe_indexing'] = sklearn.utils._safe_indexing


def plot_feature_importance(importance, names, model):
    sorted_idx = importance.argsort()
    plt.figure(figsize=(10, 15))
    plt.barh(names[sorted_idx], model.feature_importances_[sorted_idx])
    plt.title('Feature Importance')
#   plt.xlabel('FEATURE IMPORTANCE')
    plt.ylabel('Feature Names')


def shap_values(X, cols, model):
    X = pd.DataFrame(X, columns=cols)
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X)
    shap.summary_plot(shap_values, X, plot_type="bar")
    pyplot.show()
    print('\n')
    print('\n')
    shap.summary_plot(shap_values, X)


def shap_values_rf(X, cols, model):
    def predict_func(X):
        return model.predict_proba(X)[:, 1]

    X = pd.DataFrame(X, columns=cols)

    masker = shap.maskers.Independent(X)
    # explainer = shap.TreeExplainer(model)
    explainer = shap.Explainer(predict_func, masker)
    shap_values = explainer(X)

    shap.summary_plot(shap_values, X, plot_type="bar")
    pyplot.show()
    print('\n')
    print('\n')
    shap.summary_plot(shap_values, X)


def plot_tree_xgb(model, cols):
    model.get_booster().feature_names = cols.to_list()
    dot = to_graphviz(model, condition_node_params={'shape': 'box', 'style': 'filled,rounded', 'fillcolor': '#78bceb'},
                      leaf_node_params={'shape': 'box', 'style': 'filled', 'fillcolor': '#e48038'})
    return dot
