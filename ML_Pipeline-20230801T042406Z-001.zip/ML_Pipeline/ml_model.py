from sklearn.model_selection import train_test_split
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from imblearn.over_sampling import SMOTE
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn import metrics
from sklearn.metrics import roc_auc_score, classification_report
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import label_binarize
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import SVC


from xgboost import XGBClassifier
from ML_Pipeline.evaluate_metrics import cross_val_test

import warnings
warnings.filterwarnings('ignore')


def scale_data(df, class_col, cols_to_exclude):
    cols = df.select_dtypes(include=np.number).columns.tolist()
    X = df[cols]
    # X = X[X.columns.difference([class_col])]
    X = X[X.columns.difference(cols_to_exclude)]
    columns = X.columns
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    X_scaled = pd.DataFrame(X_scaled, columns=columns)
    return X_scaled

# function to create a model using normal data


def prepare_model_scaleddata(df, class_col, cols_to_exclude):
    cols = df.select_dtypes(include=np.number).columns.tolist()
    X = df[cols]
    X = X[X.columns.difference([class_col])]
    X = X[X.columns.difference(cols_to_exclude)]
    columns = X.columns

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    X_scaled = pd.DataFrame(X_scaled, columns=columns)

    y = df[class_col]  # Selecting y as a column
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.3, random_state=0, stratify=y)
    return (X_train, X_test, y_train, y_test)

# function to create a model using normal data


def prepare_model_originaldata(df, class_col, cols_to_exclude):
    cols = df.select_dtypes(include=np.number).columns.tolist()
    X = df[cols]
    X = X[X.columns.difference([class_col])]
    X = X[X.columns.difference(cols_to_exclude)]
    columns = X.columns
    y = df[class_col]  # Selecting y as a column
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=0, stratify=y)
    return (X_train, X_test, y_train, y_test)

# function to create a model using SMOTE


def prepare_model_smote(df, class_col, cols_to_exclude):
    # Synthetic Minority Oversampling Technique. Generates new instances from existing minority cases that you supply as input.
    cols = df.select_dtypes(include=np.number).columns.tolist()
    X = df[cols]
    X = X[X.columns.difference([class_col])]
    X = X[X.columns.difference(cols_to_exclude)]
    columns = X.columns
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    X_scaled = pd.DataFrame(X_scaled, columns=columns)
    y = df[class_col]  # Selecting y as a column
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.3, random_state=0, stratify=y)
    sm = SMOTE(random_state=0, sampling_strategy=1.0)
    X_train, y_train = sm.fit_resample(X_train, y_train)
    return (X_train, X_test, y_train, y_test)

# Model to  predict the ROC curve for various models and finding the best one


def all_models(X_train, y_train, X_test, y_test, model_type):

    clfs = {
        'GradientBoosting': GradientBoostingClassifier(max_depth=6, n_estimators=100, max_features=0.3, random_state=0),
        # 'LogisticRegression' : LogisticRegression(),
        # 'GaussianNB': GaussianNB(),
        # 'svm':SVC(kernel='rbf'),
        'RandomForestClassifier': RandomForestClassifier(n_estimators=100, random_state=0),
        # 'adaboost': AdaBoostClassifier(n_estimators=100),
        'XGBClassifier': XGBClassifier(n_estimators=1000, max_depth=10, learning_rate=0.990000, booster="gbtree", gamma=0.010000, subsample=0.900000, colsample_bytree=0.500000, colsample_bylevel=0.500000, colsample_bynode=0.500000, random_state=0

                                       )
    }
    cols = ['model', 'matthews_corrcoef', 'roc_auc_score',
            'precision_score', 'recall_score', 'f1_score']

    models_report = pd.DataFrame(columns=cols)

    conf_matrix = dict()

    for clf, clf_name in zip(clfs.values(), clfs.keys()):

        clf.fit(X_train, y_train)

        y_pred = clf.predict(X_test)
        y_score = clf.predict_proba(X_test)[:, 1]
        lowerbound, upperbound = cross_val_test(clf, X_train, y_train)
        if upperbound > 1:
            upperbound = 1

        print('computing {} - {} '.format(clf_name, model_type))

        tmp = pd.Series({'model_type': model_type,
                         'model': clf_name,
                         'roc_auc_score': metrics.roc_auc_score(y_test, y_score),
                         'matthews_corrcoef': metrics.matthews_corrcoef(y_test, y_pred),
                         'precision_score': metrics.precision_score(y_test, y_pred),
                         'recall_score': metrics.recall_score(y_test, y_pred),
                         'f1_score': metrics.f1_score(y_test, y_pred),
                         'f1_betascore': metrics.fbeta_score(y_test, y_pred, average='weighted', beta=0.5),
                         '95% CI lower bound': lowerbound,
                         '95% CI upper bound': upperbound
                         })

        models_report = models_report.append(tmp, ignore_index=True)
        conf_matrix[clf_name] = pd.crosstab(
            y_test, y_pred, rownames=['True'], colnames=['Predicted'], margins=False)
        fpr, tpr, thresholds = metrics.roc_curve(
            y_test, y_score, drop_intermediate=False, pos_label=1)

        plt.figure(1, figsize=(6, 6))
        plt.xlabel('false positive rate')
        plt.ylabel('true positive rate')
        plt.title('ROC curve - {}'.format(model_type))
        plt.plot(fpr, tpr, label=f'{clf_name} (area = %0.2f)' %
                 metrics.roc_auc_score(y_test, y_score))
        plt.legend(loc="lower right")
    plt.plot([0, 1], [0, 1], color='black')

    return models_report, conf_matrix

# Model to  predict the ROC curve for various models and finding the best one


def run_Xgb(X_train, y_train, X_test, y_test, model_type):

    clfs = {
        'XGBClassifier': XGBClassifier()
    }
    cols = ['model', 'matthews_corrcoef', 'roc_auc_score',
            'precision_score', 'recall_score', 'f1_score']

    models_report = pd.DataFrame(columns=cols)

    conf_matrix = dict()

    for clf, clf_name in zip(clfs.values(), clfs.keys()):

        clf.fit(X_train, y_train)

        y_pred = clf.predict(X_test)
        y_score = clf.predict_proba(X_test)[:, 1]
        lowerbound, upperbound = cross_val_test(clf, X_train, y_train)
        if upperbound > 1:
            upperbound = 1

        print('computing {} - {} '.format(clf_name, model_type))

        tmp = pd.Series({'model_type': model_type,
                         'model': clf_name,
                         'roc_auc_score': metrics.roc_auc_score(y_test, y_score),
                         'matthews_corrcoef': metrics.matthews_corrcoef(y_test, y_pred),
                         'precision_score': metrics.precision_score(y_test, y_pred),
                         'recall_score': metrics.recall_score(y_test, y_pred),
                         'f1_score': metrics.f1_score(y_test, y_pred),
                         '95% CI lower bound': lowerbound,
                         '95% CI upper bound': upperbound
                         })

        models_report = models_report.append(tmp, ignore_index=True)
        conf_matrix[clf_name] = pd.crosstab(
            y_test, y_pred, rownames=['True'], colnames=['Predicted'], margins=False)
        fpr, tpr, thresholds = metrics.roc_curve(
            y_test, y_score, drop_intermediate=False, pos_label=1)

        plt.figure(1, figsize=(6, 6))
        plt.xlabel('false positive rate')
        plt.ylabel('true positive rate')
        plt.title('ROC curve - {}'.format(model_type))
        plt.plot(fpr, tpr, label=f'{clf_name} (area = %0.2f)' %
                 metrics.roc_auc_score(y_test, y_score))
        plt.legend(loc="lower right")
    plt.plot([0, 1], [0, 1], color='black')

    return models_report, conf_matrix


def run_rf(X_train, y_train, X_test, y_test, model_type):

    clfs = {
        'RandomForestClassifier': RandomForestClassifier(n_estimators=100, random_state=0)
    }
    cols = ['model', 'matthews_corrcoef', 'roc_auc_score',
            'precision_score', 'recall_score', 'f1_score']

    models_report = pd.DataFrame(columns=cols)

    conf_matrix = dict()

    for clf, clf_name in zip(clfs.values(), clfs.keys()):

        clf.fit(X_train, y_train)

        y_pred = clf.predict(X_test)
        y_score = clf.predict_proba(X_test)[:, 1]
        lowerbound, upperbound = cross_val_test(clf, X_train, y_train)
        if upperbound > 1:
            upperbound = 1

        print('computing {} - {} '.format(clf_name, model_type))

        tmp = pd.Series({'model_type': model_type,
                         'model': clf_name,
                         'roc_auc_score': metrics.roc_auc_score(y_test, y_score),
                         'matthews_corrcoef': metrics.matthews_corrcoef(y_test, y_pred),
                         'precision_score': metrics.precision_score(y_test, y_pred),
                         'recall_score': metrics.recall_score(y_test, y_pred),
                         'f1_score': metrics.f1_score(y_test, y_pred),
                         '95% CI lower bound': lowerbound,
                         '95% CI upper bound': upperbound
                         })

        models_report = models_report.append(tmp, ignore_index=True)
        conf_matrix[clf_name] = pd.crosstab(
            y_test, y_pred, rownames=['True'], colnames=['Predicted'], margins=False)
        fpr, tpr, thresholds = metrics.roc_curve(
            y_test, y_score, drop_intermediate=False, pos_label=1)

        plt.figure(1, figsize=(6, 6))
        plt.xlabel('false positive rate')
        plt.ylabel('true positive rate')
        plt.title('ROC curve - {}'.format(model_type))
        plt.plot(fpr, tpr, label=f'{clf_name} (area = %0.2f)' %
                 metrics.roc_auc_score(y_test, y_score))
        plt.legend(loc="lower right")
    plt.plot([0, 1], [0, 1], color='black')

    return models_report, conf_matrix


# define the models


def run_model(model, X_train, X_test, y_train, y_test):
    if model == 'random':  # random forest model
        # Fitting the random forest
        randomforest = RandomForestClassifier(max_depth=5)
        randomforest.fit(X_train, y_train)
        # Predicting y valuesn
        y_pred = randomforest.predict(X_test)
        randomforest_roc_auc = roc_auc_score(
            y_test, randomforest.predict(X_test))
        print(classification_report(y_test, y_pred))
        print("The area under the curve is: %0.2f" % randomforest_roc_auc)
        return (randomforest, y_pred)

    elif model == 'adaboost':  # adabosst model
        # Fitting the adaboost
        adaboost = AdaBoostClassifier(n_estimators=100)
        adaboost.fit(X_train, y_train)
        # Predicting y values
        y_pred = adaboost.predict(X_test)
        adaboost_roc_auc = roc_auc_score(y_test, adaboost.predict(X_test))
        print(classification_report(y_test, y_pred))
        print("The area under the curve is: %0.2f" % adaboost_roc_auc)
        return (adaboost, y_pred)

    elif model == 'gradient':  # gradient boosting model
        # Fitting the logistic regression
        gradientboost = GradientBoostingClassifier()
        gradientboost.fit(X_train, y_train)
        # Predicting y values
        y_pred = gradientboost.predict(X_test)
        gradientboost_roc_auc = roc_auc_score(
            y_test, gradientboost.predict(X_test))
        print(classification_report(y_test, y_pred))
        print("The area under the curve is: %0.2f" % gradientboost_roc_auc)
        return (gradientboost, y_pred)

    else:
        print("none")


def classify_rf(x, y, X_test, y_test):
    # Passing the model and train test dataset to fit the model
    est = RandomForestClassifier(n_estimators=100, random_state=0)
    est.fit(x, y)
    # Predicting the probabilities of the Tet data
    y2 = est.predict_proba(X_test)
    y1 = est.predict(X_test)

    print("Accuracy: ", metrics.accuracy_score(y_test, y1))
    print("Area under the ROC curve: ",
          metrics.roc_auc_score(y_test, y2[:, 1]))
    # Calculate different metrics
    print("F-metric: ", metrics.f1_score(y_test, y1))
    print(" ")
    print("Classification report:")
    print(metrics.classification_report(y_test, y1))
    print(" ")
    # print("Evaluation by cross-validation:")
    # print(cross_val_score(est, x, y))

    return est, y1, y2[:, 1]


def classify(est, x, y, X_test, y_test):
    # Passing the model and train test dataset to fit the model
    est.fit(x, y)
    # Predicting the probabilities of the Tet data
    y2 = est.predict_proba(X_test)
    y1 = est.predict(X_test)

    print("Accuracy: ", metrics.accuracy_score(y_test, y1))
    print("Area under the ROC curve: ",
          metrics.roc_auc_score(y_test, y2[:, 1]))
    # Calculate different metrics
    print("F-metric: ", metrics.f1_score(y_test, y1))
    print(" ")
    print("Classification report:")
    print(metrics.classification_report(y_test, y1))
    print(" ")
    # print("Evaluation by cross-validation:")
    # print(cross_val_score(est, x, y))

    return est, y1, y2[:, 1]


def Cluster(X_train, y_train, X_test, y_test, model_def, classes, cluster):

    models_report = pd.DataFrame()

    model = OneVsRestClassifier(model_def)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    pred_prob = model.predict_proba(X_test)

    lowerbound, upperbound = cross_val_test(model_def, X_train, y_train)

    y_test_binarized = label_binarize(y_test, classes=np.unique(y_test))

    # roc curve for classes
    fpr = {}
    tpr = {}
    thresh = {}
    roc_auc = dict()
    conf_matrix = dict()
    n_class = classes.shape[0]

    for i in range(n_class):
        y_score = model.predict_proba(X_test)[:, i]
        # print('computing {} - {} '.format(clf_name, model_type))

        tmp = pd.Series({
            'model': 'Random Forest',
            'roc_auc_score': metrics.roc_auc_score(y_test_binarized[:, i], y_score),
            'matthews_corrcoef': metrics.matthews_corrcoef(y_test_binarized[:, i], y_pred),
            'precision_score': metrics.precision_score(y_test_binarized[:, i], y_pred, average='micro'),
            'recall_score': metrics.recall_score(y_test_binarized[:, i], y_pred, average='micro'),
            'f1_score': metrics.f1_score(y_test_binarized[:, i], y_pred, average='micro')
                        #  '95% CI lower bound': lowerbound,
                        #  '95% CI upper bound': upperbound
                        })

        models_report = models_report.append(tmp, ignore_index=True)
        fpr[i], tpr[i], thresh[i] = metrics.roc_curve(
            y_test_binarized[:, i], pred_prob[:, i])
        roc_auc[i] = metrics.auc(fpr[i], tpr[i])
        # plotting
        plt.plot(fpr[i], tpr[i], linestyle='--',
                 label='%s vs Rest (AUC=%0.2f)' % (classes[i], roc_auc[i]))

    plt.plot([0, 1], [0, 1], 'b--')
    plt.xlim([0, 1])
    plt.ylim([0, 1.05])
    plt.title('Multiclass ROC curve')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive rate')
    plt.legend(loc='lower right')
    plt.show()

    conf_matrix['Random Classifer '] = pd.crosstab(
        y_test, y_pred, rownames=['True'], colnames=['Predicted'], margins=False)
    return models_report, conf_matrix, model


def oneVsRest(X_train, y_train, X_test, y_test, model_def, classes, cluster):

    models_report = pd.DataFrame()

    model = OneVsRestClassifier(model_def)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    pred_prob = model.predict_proba(X_test)

    lowerbound, upperbound = cross_val_test(model_def, X_train, y_train)

    y_test_binarized = label_binarize(y_test, classes=np.unique(y_test))

    # roc curve for classes
    fpr = {}
    tpr = {}
    thresh = {}
    roc_auc = dict()

    n_class = classes.shape[0]

    for i in range(n_class):
        fpr[i], tpr[i], thresh[i] = metrics.roc_curve(
            y_test_binarized[:, i], pred_prob[:, i])
        roc_auc[i] = metrics.auc(fpr[i], tpr[i])
        # plotting
        plt.plot(fpr[i], tpr[i], linestyle='--',
                 label='%s vs Rest (AUC=%0.2f)' % (classes[i], roc_auc[i]))

    plt.plot([0, 1], [0, 1], 'b--')
    plt.xlim([0, 1])
    plt.ylim([0, 1.05])
    plt.title('Multiclass ROC curve')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive rate')
    plt.legend(loc='lower right')
    plt.show()
